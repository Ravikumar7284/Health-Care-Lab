
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class Validate extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		@SuppressWarnings("unused")
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
			PreparedStatement st = con.prepareStatement("SELECT * FROM users where uemail=? and upass=?");
			st.setString(1, email);
			st.setString(2, pass);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				HttpSession session=request.getSession();  
		        session.setAttribute("u_id",rs.getString("u_id"));
		        session.setAttribute("uname",rs.getString("uname"));
		        String redirectURL = "viewod.jsp";
				response.sendRedirect(redirectURL);
			} else {
				String redirectURL = "index.jsp?logf=1";
				response.sendRedirect(redirectURL);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
