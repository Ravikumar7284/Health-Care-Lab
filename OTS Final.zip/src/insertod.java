import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class insertod extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Statement stmt = null;
	    Connection con = null;
	    String pid=request.getParameter("pid");
	    HttpSession session1=request.getSession(false);
		long qty=Long.parseLong(request.getParameter("qty"));
		long pprice=Long.parseLong(request.getParameter("pprice"));
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try{  
			long f_price1=1;
			f_price1=qty*pprice;
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");  
			stmt=con.createStatement();
			stmt.executeQuery("insert into orders(pid,u_id,qty,f_price) values("+pid+","+(String) session1.getAttribute("u_id")+","+qty+","+f_price1+")");
			pw.print("<p>Order Placed Successfully...</p>");
			String redirectURL = "viewod.jsp?uid="+(String) session1.getAttribute("u_id");
			response.sendRedirect(redirectURL);
		} 
		catch(Exception e)
		{ System.out.println(e);} 
		
	}

}
