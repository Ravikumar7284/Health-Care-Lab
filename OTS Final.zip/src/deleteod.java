import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@SuppressWarnings("serial")
public class deleteod extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Statement stmt = null;
	       Connection con = null;
	       @SuppressWarnings("unused")
		ResultSet ord = null;
	    String oid=request.getParameter("oid");
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try{  
			
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");  
			stmt=con.createStatement();
			stmt.executeQuery("delete from orders where oid="+oid);
			pw.print("<p>Deleted Successfully</p>");
			String redirectURL = "viewod.jsp";
			response.sendRedirect(redirectURL);
		} 
		catch(Exception e)
		{ System.out.println(e);} 
		
		
	}

}
