import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class loginlogic extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		@SuppressWarnings("unused")
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String name = request.getParameter("uname");
		String email = request.getParameter("email");
		String pass = request.getParameter("psw");
		String cpass = request.getParameter("cpass");

		if (pass.equals(cpass)) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
				PreparedStatement st1 = con.prepareStatement("SELECT uname FROM users where uemail=? ");
				st1.setString(1, email);
				ResultSet rs = st1.executeQuery();
				
				if (rs.next())
				{
					String redirectURL = "index.jsp?alrg=1";
					response.sendRedirect(redirectURL);
				} 
				else 
				{
					PreparedStatement st = con.prepareStatement("INSERT INTO users (uname,uemail,upass) VALUES(?,?,?)");
					st.setString(1, name);
					st.setString(2, email);
					st.setString(3, cpass);
					st.executeQuery();
					String redirectURL = "index.jsp?regs=1";
					response.sendRedirect(redirectURL);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		else {
			request.setAttribute("pdnm", "1");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
}
